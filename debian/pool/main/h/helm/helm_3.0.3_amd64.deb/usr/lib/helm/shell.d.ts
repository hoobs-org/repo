/**************************************************************************************************
 * helm                                                                                           *
 * Copyright (C) 2020 HOOBS                                                                       *
 *                                                                                                *
 * This program is free software: you can redistribute it and/or modify                           *
 * it under the terms of the GNU General Public License as published by                           *
 * the Free Software Foundation, either version 3 of the License, or                              *
 * (at your option) any later version.                                                            *
 *                                                                                                *
 * This program is distributed in the hope that it will be useful,                                *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                 *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                  *
 * GNU General Public License for more details.                                                   *
 *                                                                                                *
 * You should have received a copy of the GNU General Public License                              *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.                          *
 **************************************************************************************************/
import IO from "socket.io";
import { Express } from "express-serve-static-core";
export default class Shell {
    time: number;
    hide: boolean;
    running: boolean;
    readonly port: number;
    private shells;
    private server;
    private listner;
    readonly app: Express;
    readonly io: IO.Server;
    private enviornment;
    constructor(port: number | undefined);
    groups(username: string): string[];
    static exiting(value: any): boolean;
    static issue(): string;
    static getty(value: string): string;
    static hostname(): string;
    static architecture(): string;
    static validate(password: string, updated: string, confirm: string): boolean;
    stop(): Promise<void>;
    start(): void;
}
//# sourceMappingURL=shell.d.ts.map