/**************************************************************************************************
 * hoobsd                                                                                         *
 * Copyright (C) 2020 HOOBS                                                                       *
 *                                                                                                *
 * This program is free software: you can redistribute it and/or modify                           *
 * it under the terms of the GNU General Public License as published by                           *
 * the Free Software Foundation, either version 3 of the License, or                              *
 * (at your option) any later version.                                                            *
 *                                                                                                *
 * This program is distributed in the hope that it will be useful,                                *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                 *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                  *
 * GNU General Public License for more details.                                                   *
 *                                                                                                *
 * You should have received a copy of the GNU General Public License                              *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.                          *
 **************************************************************************************************/
import { LogLevel, Logging } from "homebridge/lib/logger";
export interface Message {
    level: LogLevel;
    bridge?: string;
    display?: string;
    timestamp: number;
    plugin?: string;
    prefix?: string;
    message: string;
}
export interface PluginLogger extends Logging {
    plugin?: string;
}
export interface Loggers {
    [key: string]: PluginLogger;
}
export declare const enum NotificationType {
    INFO = "info",
    SUCCESS = "success",
    WARN = "warn",
    ERROR = "error",
    DEBUG = "debug"
}
export declare const enum Events {
    PING = "ping",
    PONG = "pong",
    LOG = "log",
    LISTENING = "listening",
    MONITOR = "monitor",
    HEARTBEAT = "heartbeat",
    NOTIFICATION = "notification",
    ACCESSORY_CHANGE = "accessory_change",
    ROOM_CHANGE = "room_change",
    CONFIG_CHANGE = "config_change",
    PUBLISH_SETUP_URI = "publish_setup_uri",
    REQUEST = "request",
    COMPLETE = "complete",
    SHUTDOWN = "shutdown",
    RESTART = "restart"
}
declare class Logger {
    plugin?: string;
    prefix: string;
    constructor(plugin?: string, prefix?: string);
    cache(tail?: number, bridge?: string): Message[];
    save(): void;
    load(): void;
    log(level: LogLevel, message: string | Message, ...parameters: any[]): void;
    debug(message: string, ...parameters: any[]): void;
    info(message: string, ...parameters: any[]): void;
    warn(message: string, ...parameters: any[]): void;
    error(message: string, ...parameters: any[]): void;
    notify(bridge: string, title: string, description: string, type: NotificationType, icon?: string): void;
    emit(event: Events, bridge: string, data: any): void;
}
export declare function Print(...parameters: any[]): void;
export declare const Console: Logger;
export declare function Prefixed(plugin: string, prefix: string): PluginLogger;
export {};
//# sourceMappingURL=logger.d.ts.map