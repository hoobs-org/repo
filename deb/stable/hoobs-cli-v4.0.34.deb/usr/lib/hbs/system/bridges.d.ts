/**************************************************************************************************
 * hoobs-cli                                                                                      *
 * Copyright (C) 2020 HOOBS                                                                       *
 *                                                                                                *
 * This program is free software: you can redistribute it and/or modify                           *
 * it under the terms of the GNU General Public License as published by                           *
 * the Free Software Foundation, either version 3 of the License, or                              *
 * (at your option) any later version.                                                            *
 *                                                                                                *
 * This program is distributed in the hope that it will be useful,                                *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                 *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                  *
 * GNU General Public License for more details.                                                   *
 *                                                                                                *
 * You should have received a copy of the GNU General Public License                              *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.                          *
 **************************************************************************************************/
import Archiver from "archiver";
export interface BridgeRecord {
    id: string;
    type: string;
    display: string;
    port: number;
    pin?: string;
    username?: string;
    ports?: {
        [key: string]: number;
    };
    autostart?: number;
    host?: string;
    plugins?: string;
    advertiser?: string;
    project?: string;
}
export default class Bridges {
    static locate(): string;
    static network(): string[];
    static list(): BridgeRecord[];
    static uninstall(name: string): boolean;
    static install(): boolean;
    static append(id: string, display: string, type: string, port: number, pin: string, username: string, autostart: number, advertiser: string, project?: string): void;
    static create(name: string, port: number, pin: string, autostart: number, advertiser?: string): Promise<boolean>;
    static cache(): {
        [key: string]: any;
    }[];
    static purge(uuid?: string): void;
    static reset(): Promise<void>;
    static export(id: string): Promise<string>;
    static backup(): Promise<string>;
    static dig(archive: Archiver.Archiver, directory: string): void;
    static metadata(file: string): Promise<{
        [key: string]: any;
    }>;
    static restore(file: string, remove?: boolean): Promise<void>;
}
//# sourceMappingURL=bridges.d.ts.map