/**************************************************************************************************
 * hoobsd                                                                                         *
 * Copyright (C) 2020 HOOBS                                                                       *
 *                                                                                                *
 * This program is free software: you can redistribute it and/or modify                           *
 * it under the terms of the GNU General Public License as published by                           *
 * the Free Software Foundation, either version 3 of the License, or                              *
 * (at your option) any later version.                                                            *
 *                                                                                                *
 * This program is distributed in the hope that it will be useful,                                *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                 *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                  *
 * GNU General Public License for more details.                                                   *
 *                                                                                                *
 * You should have received a copy of the GNU General Public License                              *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.                          *
 **************************************************************************************************/
/// <reference types="node" />
import { SpawnOptionsWithoutStdio } from "child_process";
export declare const enum ProcessQuery {
    PID = "pid",
    PORT = "port"
}
export default class System {
    static preload(): void;
    static info(): {
        [key: string]: any;
    };
    static hostname(value: string): void;
    static kill(type: ProcessQuery, value: any): void;
    static shell(command: string, multiline?: boolean): string;
    static execute(command: string, options?: SpawnOptionsWithoutStdio): Promise<void>;
    static restart(): void;
    static reboot(): void;
    static shutdown(): void;
    static switch(level: string): void;
    static get gui(): {
        [key: string]: any;
    };
    static get cli(): {
        [key: string]: any;
    };
    static get hoobsd(): {
        [key: string]: any;
    };
    static get runtime(): {
        [key: string]: any;
    };
}
//# sourceMappingURL=system.d.ts.map