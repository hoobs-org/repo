/**************************************************************************************************
 * hoobsd                                                                                         *
 * Copyright (C) 2020 HOOBS                                                                       *
 *                                                                                                *
 * This program is free software: you can redistribute it and/or modify                           *
 * it under the terms of the GNU General Public License as published by                           *
 * the Free Software Foundation, either version 3 of the License, or                              *
 * (at your option) any later version.                                                            *
 *                                                                                                *
 * This program is distributed in the hope that it will be useful,                                *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                 *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                  *
 * GNU General Public License for more details.                                                   *
 *                                                                                                *
 * You should have received a copy of the GNU General Public License                              *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.                          *
 **************************************************************************************************/
import IO from "socket.io";
import { Express } from "express-serve-static-core";
import { DotenvParseOutput } from "dotenv";
import { IPC } from "./services/ipc";
import { Loggers } from "./services/logger";
import Cache from "./services/cache";
import Bridge from "./bridge";
import Homebridge from "./bridge/server";
import Hub from "./hub";
import { BridgeRecord } from "./services/bridges";
import { UserRecord } from "./services/users";
export interface Application {
    version: string;
    engine: string;
    mode: string;
    enviornment: DotenvParseOutput | undefined;
    app: Express | undefined;
    io: IO.Server | undefined;
    ipc: IPC | undefined;
    cache: Cache | undefined;
    hub: Hub | undefined;
    bridge: Bridge | undefined;
    homebridge: Homebridge | undefined;
    setup: string | undefined;
    id: string;
    display: string;
    debug: boolean;
    verbose: boolean;
    timestamps: boolean;
    orphans: boolean;
    container: boolean;
    terminating: boolean;
    restoring: boolean;
    saving: boolean;
    bridges: BridgeRecord[];
    users: UserRecord[];
    loggers: Loggers;
    plugins: {
        [key: string]: any;
    };
    project: string | undefined;
}
declare const state: Application;
export default state;
//# sourceMappingURL=state.d.ts.map