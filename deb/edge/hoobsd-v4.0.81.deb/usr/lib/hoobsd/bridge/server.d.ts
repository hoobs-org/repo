/**************************************************************************************************
 * hoobsd                                                                                         *
 * Copyright (C) 2020 HOOBS                                                                       *
 * Copyright (C) 2020 Homebridge                                                                  *
 *                                                                                                *
 * This program is free software: you can redistribute it and/or modify                           *
 * it under the terms of the GNU General Public License as published by                           *
 * the Free Software Foundation, either version 3 of the License, or                              *
 * (at your option) any later version.                                                            *
 *                                                                                                *
 * This program is distributed in the hope that it will be useful,                                *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                 *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                  *
 * GNU General Public License for more details.                                                   *
 *                                                                                                *
 * You should have received a copy of the GNU General Public License                              *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.                          *
 **************************************************************************************************/
/// <reference types="node" />
import { EventEmitter } from "events";
import { Accessory } from "hap-nodejs";
import { BridgeConfiguration } from "homebridge/lib/bridgeService";
import { PlatformAccessory } from "homebridge/lib/platformAccessory";
import Accessories from "./services/accessories";
import { BridgeRecord } from "../services/bridges";
export default class Server extends EventEmitter {
    running: boolean;
    readonly port: number;
    readonly settings: BridgeConfiguration;
    readonly instance: BridgeRecord | undefined;
    readonly accessories: Accessories;
    private readonly api;
    private readonly pluginManager;
    private readonly bridge;
    private readonly config;
    private readonly externalPorts;
    private hapAccessories;
    private platformAccessories;
    private development;
    private readonly unbridgedAccessories;
    constructor(port?: number, development?: boolean);
    start(): Promise<void>;
    stop(): Promise<void>;
    setupURI(): string;
    private getAdvertiser;
    private publishBridge;
    get getAccessories(): (PlatformAccessory | Accessory)[];
    private loadCachedPlatformAccessoriesFromDisk;
    saveCachedPlatformAccessoriesOnDisk(): void;
    private restoreCachedPlatformAccessories;
    private resetAccessoryMemCache;
    private loadAccessories;
    private loadPlatforms;
    private loadPlatformAccessories;
    private createHAPAccessory;
    private handleRegisterPlatformAccessories;
    private handleUpdatePlatformAccessories;
    private handleUnregisterPlatformAccessories;
    private handlePublishExternalAccessories;
    private addHoobsInformation;
    private addHoobsEvents;
}
//# sourceMappingURL=server.d.ts.map