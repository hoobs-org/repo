/**************************************************************************************************
 * hoobs-cli                                                                                      *
 * Copyright (C) 2020 HOOBS                                                                       *
 *                                                                                                *
 * This program is free software: you can redistribute it and/or modify                           *
 * it under the terms of the GNU General Public License as published by                           *
 * the Free Software Foundation, either version 3 of the License, or                              *
 * (at your option) any later version.                                                            *
 *                                                                                                *
 * This program is distributed in the hope that it will be useful,                                *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                 *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                  *
 * GNU General Public License for more details.                                                   *
 *                                                                                                *
 * You should have received a copy of the GNU General Public License                              *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.                          *
 **************************************************************************************************/
export default class Paths {
    static touch(filename: string): void;
    static loadJson<T>(file: string, replacement: T, key?: string, compressed?: boolean): T;
    static saveJson<T>(file: string, value: T, pretty?: boolean, key?: string, compress?: boolean): void;
    static tryCommand(command: string): boolean;
    static tryUnlink(filename: string): boolean;
    static isEmpty(path: string): boolean;
    static get application(): string;
    static get yarn(): string;
    static data(bridge?: string): string;
    static get log(): string;
    static get bridges(): string;
    static get config(): string;
    static get backups(): string;
}
//# sourceMappingURL=paths.d.ts.map