/**************************************************************************************************
 * hoobsd                                                                                         *
 * Copyright (C) 2020 HOOBS                                                                       *
 *                                                                                                *
 * This program is free software: you can redistribute it and/or modify                           *
 * it under the terms of the GNU General Public License as published by                           *
 * the Free Software Foundation, either version 3 of the License, or                              *
 * (at your option) any later version.                                                            *
 *                                                                                                *
 * This program is distributed in the hope that it will be useful,                                *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                 *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                  *
 * GNU General Public License for more details.                                                   *
 *                                                                                                *
 * You should have received a copy of the GNU General Public License                              *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.                          *
 **************************************************************************************************/
import { Request, Response } from "express-serve-static-core";
export default class AccessoriesController {
    constructor();
    static get layout(): {
        [key: string]: any;
    };
    static set layout(value: {
        [key: string]: any;
    });
    list(request: Request, response: Response): Promise<void>;
    hidden(_request: Request, response: Response): Promise<void>;
    get(request: Request, response: Response, push?: boolean, value?: any): Promise<void>;
    stream(request: Request, response: Response): Promise<void>;
    snapshot(request: Request, response: Response): Promise<void>;
    set(request: Request, response: Response): Promise<void>;
    characteristics(request: Request, response: Response): Promise<void>;
    rooms(_request: Request, response: Response): Promise<Response>;
    room(request: Request, response: Response): Promise<Response>;
    private properties;
    remove(request: Request, response: Response): Promise<Response>;
    add(request: Request, response: Response): Response;
    update(request: Request, response: Response): Promise<Response>;
    private controllable;
    private accessories;
}
//# sourceMappingURL=accessories.d.ts.map