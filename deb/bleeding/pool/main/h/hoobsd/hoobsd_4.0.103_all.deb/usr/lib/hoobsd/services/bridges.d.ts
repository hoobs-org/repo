/**************************************************************************************************
 * hoobsd                                                                                         *
 * Copyright (C) 2020 HOOBS                                                                       *
 *                                                                                                *
 * This program is free software: you can redistribute it and/or modify                           *
 * it under the terms of the GNU General Public License as published by                           *
 * the Free Software Foundation, either version 3 of the License, or                              *
 * (at your option) any later version.                                                            *
 *                                                                                                *
 * This program is distributed in the hope that it will be useful,                                *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                 *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                  *
 * GNU General Public License for more details.                                                   *
 *                                                                                                *
 * You should have received a copy of the GNU General Public License                              *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.                          *
 **************************************************************************************************/
/// <reference types="node" />
import Archiver from "archiver";
import { ChildProcess } from "child_process";
import Socket from "../hub/services/socket";
export interface BridgeRecord {
    id: string;
    type: string;
    display: string;
    port: number;
    pin?: string;
    username?: string;
    ports?: {
        [key: string]: number;
    };
    autostart?: number;
    host?: string;
    plugins?: string;
    advertiser?: string;
    project?: string;
    debugging?: boolean;
}
export interface BridgeProcess {
    bridge: BridgeRecord;
    port: number;
    process: ChildProcess;
    socket: Socket;
}
export default class Bridges {
    static running(pid: number): boolean;
    static locate(): string;
    static network(): string[];
    static extentions(): {
        [key: string]: string | boolean;
    }[];
    static list(): BridgeRecord[];
    static kill(bridge: BridgeRecord): void;
    static manage(action: string): Promise<unknown>;
    static update(name: string): {
        [key: string]: any;
    };
    static uninstall(name: string): boolean;
    static append(id: string, display: string, type: string, port: number, pin: string, username: string, autostart: number, advertiser: string): void;
    static create(name: string, port: number, pin: string, username: string, advertiser: string): void;
    static accessories(bridge: string): {
        [key: string]: any;
    }[];
    static parings(bridge: string): {
        [key: string]: any;
    }[];
    static purge(name: string, uuid?: string): void;
    static reset(): Promise<void>;
    static export(id: string): Promise<string>;
    static backup(): Promise<string>;
    static dig(archive: Archiver.Archiver, directory: string): void;
    static metadata(file: string): Promise<{
        [key: string]: any;
    }>;
    static import(name: string, port: number, pin: string, username: string, advertiser: string, file: string, remove?: boolean): Promise<void>;
    static restore(file: string, remove?: boolean): Promise<void>;
}
//# sourceMappingURL=bridges.d.ts.map