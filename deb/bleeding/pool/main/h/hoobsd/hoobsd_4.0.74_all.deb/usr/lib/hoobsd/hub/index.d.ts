/**************************************************************************************************
 * hoobsd                                                                                         *
 * Copyright (C) 2020 HOOBS                                                                       *
 *                                                                                                *
 * This program is free software: you can redistribute it and/or modify                           *
 * it under the terms of the GNU General Public License as published by                           *
 * the Free Software Foundation, either version 3 of the License, or                              *
 * (at your option) any later version.                                                            *
 *                                                                                                *
 * This program is distributed in the hope that it will be useful,                                *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                 *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                  *
 * GNU General Public License for more details.                                                   *
 *                                                                                                *
 * You should have received a copy of the GNU General Public License                              *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.                          *
 **************************************************************************************************/
/// <reference types="node" />
import { EventEmitter } from "events";
import { BridgeRecord } from "../services/bridges";
export default class API extends EventEmitter {
    time: number;
    running: boolean;
    config: any;
    settings: any;
    readonly port: number;
    private enviornment;
    private bridges;
    private listner;
    private terminator;
    constructor(port: number | undefined);
    static createServer(port: number): API;
    reload(): void;
    launch(bridge: BridgeRecord): void;
    teardown(bridge: BridgeRecord | string): Promise<void>;
    sync(): Promise<void>;
    start(): Promise<void>;
    stop(): Promise<void>;
}
//# sourceMappingURL=index.d.ts.map