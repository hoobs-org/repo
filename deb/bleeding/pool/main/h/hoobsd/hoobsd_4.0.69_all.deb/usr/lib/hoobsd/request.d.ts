declare const request: import("axios").AxiosInstance;
export default request;
//# sourceMappingURL=request.d.ts.map