/// <reference types="node" />
import { Writable } from "stream";
export default class Pipe extends Writable {
    callback: any;
    constructor(callback: (chunk: any) => void);
    _write(chunk: any, _encoding: BufferEncoding, callback: (error?: Error) => void): void;
}
//# sourceMappingURL=pipe.d.ts.map