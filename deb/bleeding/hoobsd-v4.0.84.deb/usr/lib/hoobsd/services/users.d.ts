/**************************************************************************************************
 * hoobsd                                                                                         *
 * Copyright (C) 2020 HOOBS                                                                       *
 *                                                                                                *
 * This program is free software: you can redistribute it and/or modify                           *
 * it under the terms of the GNU General Public License as published by                           *
 * the Free Software Foundation, either version 3 of the License, or                              *
 * (at your option) any later version.                                                            *
 *                                                                                                *
 * This program is distributed in the hope that it will be useful,                                *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of                                 *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                  *
 * GNU General Public License for more details.                                                   *
 *                                                                                                *
 * You should have received a copy of the GNU General Public License                              *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.                          *
 **************************************************************************************************/
export interface UserRecord {
    id: number;
    name: string;
    permissions: {
        [key: string]: boolean;
    };
    username: string;
    password: string;
    salt: string;
}
export default class Users {
    static list(): UserRecord[];
    static count(): number;
    static generateSalt(): Promise<string>;
    static hashValue(value: string, salt: string): Promise<string>;
    static generateToken(id: number, remember?: boolean): Promise<string | boolean>;
    static decodeToken(token: string | undefined): {
        [key: string]: any;
    };
    static validateToken(token: string | undefined): Promise<boolean>;
    static get(username: string): UserRecord | undefined;
    static create(name: string, username: string, password: string, permissions: {
        [key: string]: boolean;
    }): Promise<UserRecord>;
    static update(id: number, name: string, username: string, password?: string, permissions?: {
        [key: string]: boolean;
    }): Promise<UserRecord | boolean>;
    static delete(id: number): boolean;
}
//# sourceMappingURL=users.d.ts.map